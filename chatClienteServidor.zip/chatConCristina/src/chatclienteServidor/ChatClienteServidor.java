
package chatclienteServidor;


public class ChatClienteServidor {

  
    public static void main(String[] args) {
       Quien principal = new Quien();
       principal.setVisible(true);
    }
    
}
